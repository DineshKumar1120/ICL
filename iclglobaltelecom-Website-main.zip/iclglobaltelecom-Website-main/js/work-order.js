function getDate() {
    debugger
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth() + 1; //January is 0!
    var yyyy = today.getFullYear();

    if (dd < 10) {
        dd = '0' + dd
    }

    if (mm < 10) {
        mm = '0' + mm
    }

    today = dd + '/' + mm + '/' + yyyy;
    console.log(today);
    document.getElementById("date").innerHTML = today;
}

function SendMobileOtp() {
    var contact = document.getElementById("vendorContact").value.trim();
    if (contact == "") {
        alert("Please provid the Contact No");
    }
}

function SendEmailOtp() {
    var email = document.getElementById("vendorEmail").value.trim();
    if (email == "") {
        alert("Please provid the Email Id");
    }
}
window.onload = function () {
    getDate();
    document.getElementById("organization").value = "ICL";
    document.getElementById("project").value = "RS Ssoft TechGlobal Services";
    document.getElementById("companyName").value = "ICL Global Telecommunication Services Pvt Ltd";
    document.getElementById("address").value = " Level-7 Tamarai Tech park, SP plot no -16/19/20-A, Jawaharlal nehru road Thiruvi- ka industrial estate,Guindy ,Chennai -600032";
    document.getElementById("contactNo").value = "+91 9962234066";
    document.getElementById("emailId").value = "chennai@iclglobaltelecom.com";
};